package com.harvic.PullScrollListViewDemo;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.ListView;

/**
 * Created by qijian on 15/8/26.
 */
public class PullScrollListView extends ListView {
    //用户定义的手指可移动的最大高度,在这里，手指移动距离是content移动距离的两倍，是header移动距离的四倍
    private int mContentMaxMoveHeight = 0;

    public PullScrollListView(Context context) {
        super(context);
    }

    public PullScrollListView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public PullScrollListView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        if (null != attrs) {
            TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.PullScrollView);
            if (ta != null) {
                mContentMaxMoveHeight = (int) ta.getDimension(R.styleable.PullScrollView_maxMoveHeight, -1);
                ta.recycle();

            }
        }
    }
}
