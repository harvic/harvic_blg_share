package com.example.BlogWebView_3;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.*;
import android.widget.Toast;

import java.net.URLEncoder;

/**
 * 1\LoadData 只能加载代码段,不能加载图片
 * 2\使用loadDataWithBaseURL可以加载图片
 */
public class MyActivity extends Activity {
    private WebView mWebView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        mWebView = (WebView) findViewById(R.id.webview);
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.getSettings().setDefaultTextEncodingName("utf-8");


        /**
         * webChromeClient demo
         */
        blog_part1_demo();

        /**
         * loadData demo
         */
//        loadDataDemo();

        /**
         * loadDataWithBaseURL Demo
         */
//        loadDataWithBaseURLDemo();
    }

    private void blog_part1_demo(){
        mWebView.setWebViewClient(new WebViewClient());
        mWebView.setWebChromeClient(new WebChromeClient(){
            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                Toast.makeText(MyActivity.this,"xxx",Toast.LENGTH_SHORT).show();
                result.confirm();
                return true;
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Toast.makeText(MyActivity.this,consoleMessage.message(),Toast.LENGTH_SHORT).show();
                return  true;
            }

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                Log.e("qijian","progress:"+newProgress);
                super.onProgressChanged(view, newProgress);
            }
        });

        mWebView.loadUrl("file:///android_asset/web.html");
//        mWebView.loadUrl("http://blog.csdn.net/harvic880925");
    }

    private void loadDataDemo(){
        try {
            String summary = "<html><body>You scored <b>192</b> points.</body></html>";
            mWebView.loadData(URLEncoder.encode(summary, "utf-8"), "text/html", "utf-8");
        } catch (Exception e) {
            Log.e("qijian", e.getMessage());
        }
    }

    private void loadDataWithBaseURLDemo(){
        String baseURL = "http://img6.ph.126.net";
        String data = "绝对网页地址:" +
                "<img src='http://img3.3lian.com/2013/v8/72/d/61.jpg'>" +
                "本地地址:" +
                "<img src='file:///android_asset/s07.jpg'>" +
                "相对地址:" +
                "<img src='hBiG96B8egigBULxUWcOpA==/109212290980771276.jpg'>";

        mWebView.loadDataWithBaseURL(baseURL, data, "text/html", "utf-8", null);
    }
}
