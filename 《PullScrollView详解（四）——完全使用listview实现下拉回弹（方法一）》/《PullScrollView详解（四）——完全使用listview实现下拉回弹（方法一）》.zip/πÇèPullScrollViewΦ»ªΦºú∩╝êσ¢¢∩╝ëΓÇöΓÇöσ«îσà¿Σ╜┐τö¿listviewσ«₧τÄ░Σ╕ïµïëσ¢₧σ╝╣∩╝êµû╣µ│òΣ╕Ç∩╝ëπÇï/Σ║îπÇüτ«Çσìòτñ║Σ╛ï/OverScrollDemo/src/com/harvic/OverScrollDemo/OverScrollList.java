package com.harvic.OverScrollDemo;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;

/**
 * Created by qijian on 15/8/20.
 */
class OverScrollList extends ListView {
    //定义最大滚动高度
    int mContentMaxMoveHeight = 300;

    public OverScrollList(Context context) {
        super(context);
    }

    public OverScrollList(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public OverScrollList(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    protected boolean overScrollBy(int deltaX, int deltaY, int scrollX, int scrollY, int scrollRangeX, int scrollRangeY, int maxOverScrollX, int maxOverScrollY, boolean isTouchEvent) {

        return super.overScrollBy(deltaX, deltaY, scrollX, scrollY, scrollRangeX, scrollRangeY, maxOverScrollX, mContentMaxMoveHeight, isTouchEvent);
    }
}
