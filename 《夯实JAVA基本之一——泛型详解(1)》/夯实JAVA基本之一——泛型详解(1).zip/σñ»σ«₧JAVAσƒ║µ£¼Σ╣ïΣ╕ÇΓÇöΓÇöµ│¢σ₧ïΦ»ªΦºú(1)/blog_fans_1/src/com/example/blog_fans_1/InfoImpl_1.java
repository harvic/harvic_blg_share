package com.example.blog_fans_1;

/**
 * 使用方法一：非泛型类
 * Created by qijian on 15/11/15.
 */
public class InfoImpl_1 implements Info<String>{	// 定义泛型接口的子类
    private String var ;				// 定义属性
    public InfoImpl_1(String var){		// 通过构造方法设置属性内容
        this.setVar(var) ;
    }
    @Override
    public void setVar(String var){
        this.var = var ;
    }
    @Override
    public String getVar(){
        return this.var ;
    }
}