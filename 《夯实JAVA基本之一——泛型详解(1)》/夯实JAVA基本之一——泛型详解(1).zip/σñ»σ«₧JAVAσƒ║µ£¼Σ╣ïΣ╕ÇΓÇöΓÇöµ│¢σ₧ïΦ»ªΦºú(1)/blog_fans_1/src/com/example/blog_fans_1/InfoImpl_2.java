package com.example.blog_fans_1;

/**
 * 使用方法二：泛型类
 * Created by qijian on 15/11/15.
 */
public class InfoImpl_2 <T> implements Info<T>{	// 定义泛型接口的子类
    private T var ;				// 定义属性
    public InfoImpl_2(T var){		// 通过构造方法设置属性内容
        this.setVar(var) ;
    }
    public void setVar(T var){
        this.var = var ;
    }
    public T getVar(){
        return this.var ;
    }
}
