package com.example.blog_fans_1;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class MyActivity extends Activity {
    private String TAG = "qijian";

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        /**
         * 1.2没有泛型会怎样
         */
        //(1),在没有使用Object时，要分别写两个相同的方法IntegerPoint和FloatPoint
        //虽然他们完成的功能差不多，但我们必须分开写，因为Integer和Float不是同一种类型
        IntegerPoint integerPoint = new IntegerPoint();
        integerPoint.setX(new Integer(123));
        Log.d(TAG, "（1）、integerPoint.getX():" + integerPoint.getX());

        FloatPoint floatPoint = new FloatPoint();
        floatPoint.setX(new Float(100.234));
        Log.d(TAG, "（1）、floatPoint.getX():" + floatPoint.getX());

        //(2)、进阶一下，将IntegerPoint与FloatPoint合并，使用Object的强制转换实现
        //但在get结果时必须进行强制转换，万一转换类型出错，运行时就会出现类型转换错误，编译期无法检查出来
        ObjectPoint objectPoint4Int = new ObjectPoint();
        objectPoint4Int.setX(new Integer(100));
        Integer integerX = (Integer) objectPoint4Int.getX();
        Log.d(TAG, "（2）、objectPoint4Int.getX():" + integerX);

        ObjectPoint objectPoint4Float = new ObjectPoint();
        objectPoint4Float.setX(new Float(100.123));
        Float floatX = (Float) objectPoint4Float.getX();
        Log.d(TAG, "（2）、objectPoint4Int.getX():" + floatX);

        /**
         * 2.1泛型类定义及使用
         */
        //(3)，再进阶一下，使用泛型
        //同样简化了代码，但在调用getX()时就不会出错，而且在setX()时，如果不是指定类型，会编译报错，
        // 大家可以把new Integer(100)与new Float(100.12f)对调一下，就知道了
        //IntegerPoint使用
        Point<Integer> intpoint = new Point<Integer>();
        intpoint.setX(new Integer(100));
        System.out.println(intpoint.getX());

        //FloatPoint使用
        Point<Float> floatPoint1 = new Point<Float>();
        floatPoint1.setX(new Float(100.12f));
        System.out.println(floatPoint1.getX());

        /**
         * 2.2多泛型变量定义
         */

        MorePoint<Integer,String> morePoint = new MorePoint<Integer, String>();
        morePoint.setName("harvic");
        Log.d(TAG, "morPont.getName:" + morePoint.getName());

        /**
         * 2.3  泛型接口定义及使用
         */
        //使用方法一：非泛型类
        InfoImpl_1 info_1 = new InfoImpl_1("harvic");
        System.out.println(info_1.getVar()) ;

        // 使用方法二：泛型类
        InfoImpl_2<String> info_2 = new InfoImpl_2<String>("harvic");
        System.out.println(info_2.getVar()) ;

        /**
         * 2.4、泛型函数定义及使用
         */
        //静态方法
        StaticFans.StaticMethod("adfdsa");//使用方法一
        StaticFans.<String>StaticMethod("adfdsa");//使用方法二

        //常规方法
        StaticFans staticFans = new StaticFans();
        staticFans.OtherMethod(new Integer(123));//使用方法一
        staticFans.<Integer>OtherMethod(new Integer(123));//使用方法二

        /**
         * 2.6 定义泛型数组
         */
        Integer i[] = fun1(1,2,3,4,5,6) ;
        Integer[] result = fun1(i) ;
        String str = "";
        for (Integer integer:result){
            str += integer;
        }
        Log.d(TAG,str);


    }


    //设置Integer类型的点坐标
    class IntegerPoint {
        private Integer x;       // 表示X坐标
        private Integer y;       // 表示Y坐标

        public void setX(Integer x) {
            this.x = x;
        }

        public void setY(Integer y) {
            this.y = y;
        }

        public Integer getX() {
            return this.x;
        }

        public Integer getY() {
            return this.y;
        }
    }

    //设置Float类型的点坐标
    class FloatPoint {
        private Float x;       // 表示X坐标
        private Float y;       // 表示Y坐标

        public void setX(Float x) {
            this.x = x;
        }

        public void setY(Float y) {
            this.y = y;
        }

        public Float getX() {
            return this.x;
        }

        public Float getY() {
            return this.y;
        }
    }


    class ObjectPoint {
        private Object x;
        private Object y;

        public void setX(Object x) {
            this.x = x;
        }

        public void setY(Object y) {
            this.y = y;
        }

        public Object getX() {
            return this.x;
        }

        public Object getY() {
            return this.y;
        }
    }

    class Point<T> {// 此处可以随便写标识符号
        private T x;
        private T y;

        public void setX(T x) {//作为参数
            this.x = x;
        }

        public void setY(T y) {
            this.y = y;
        }

        public T getX() {//作为返回值
            return this.x;
        }

        public T getY() {
            return this.y;
        }
    }


    class MorePoint<T,U> {
        private T x;
        private T y;

        private U name;

        public void setX(T x) {
            this.x = x;
        }

        public void setY(T y) {
            this.y = y;
        }

        public T getX() {
            return this.x;
        }

        public T getY() {
            return this.y;
        }

        public void setName(U name){
            this.name = name;
        }

        public U getName() {
            return this.name;
        }
    }

    //定义泛型数组
    public static <T> T[] fun1(T...arg){  // 接收可变参数
        return arg ;            // 返回泛型数组
    }



}
