package com.example.blog_fans_1;

import java.util.Iterator;

/**
 * 泛型接口
 * Created by qijian on 15/11/12.
 */
public interface Info<T>{
    public T getVar() ; // 定义抽象方法，抽象方法的返回值就是泛型类型
    public void setVar(T x);
}
