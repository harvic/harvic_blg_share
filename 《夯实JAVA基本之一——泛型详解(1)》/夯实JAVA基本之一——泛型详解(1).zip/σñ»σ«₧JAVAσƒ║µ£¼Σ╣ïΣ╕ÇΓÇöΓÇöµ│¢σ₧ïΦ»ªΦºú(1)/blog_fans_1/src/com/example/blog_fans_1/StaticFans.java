package com.example.blog_fans_1;

import android.util.Log;

/**
 * 泛型函数定义及使用
 * Created by qijian on 15/11/15.
 */
public class StaticFans {
    //静态函数
    public static  <T> void StaticMethod(T a){
        Log.d("harvic", "StaticMethod: " + a.toString());
    }
    //普通函数
    public  <T> void OtherMethod(T a){
        Log.d("harvic","OtherMethod: "+a.toString());
    }
}
