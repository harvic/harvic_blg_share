package com.harvic.blog_fans_2;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class MyActivity extends Activity {
    private String TAG = "qijian";
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        /**
         * 1.1引入泛型
         */
        Point<Integer> p1 = new Point<Integer>();
        p1.setX(new Integer(100));
        System.out.println(p1.getX());

        /**
         * 1.2.2、extends实例：绑定接口
         */
        StringCompare result = min(new  StringCompare("123"),new StringCompare("234"),new StringCompare("59897"));
        Log.d(TAG, "min:" + result.mStr);

        /**
         *1.2.3 extends实例：绑定类
         */
        String name_1 = getFruitName(new Banana());
        String name_2 = getFruitName(new Apple());
        Log.d(TAG,name_1);
        Log.d(TAG,name_2);

        /**
         * 2.1引入：未用通配符前
         */
        Point<Integer> integerPoint = new Point<Integer>(3,3);
        //…………
        Point<Float> floatPoint = new Point<Float>(4.3f,4.3f);
        //…………
        Point<Double> doublePoint = new Point<Double>(4.3d,4.90d);
        //…………
        Point<Long> longPoint = new Point<Long>(12l,23l);
        //…………

        /**
         * 2.2 无边界通配符 ?
         */
        Point<?> point;

        point = new Point<Integer>(3,3);
        point = new Point<Float>(4.3f,4.3f);
        point = new Point<Double>(4.3d,4.90d);
        point = new Point<Long>(12l,23l);

        /**
         * 2.3 通配符？的extends绑定
         */
        Point<? extends Number> pointNum;

        pointNum = new Point<Integer>(3,3);
        pointNum = new Point<Float>(4.3f,4.3f);
        pointNum = new Point<Double>(4.3d,4.90d);
        pointNum = new Point<Long>();
//        pointNum = new Point<String>(); //编译错误
//        pointNum = new Point<Object>()  //编译错误

        //从根本上解决Point中泛型变量T只能派生自Number的问题
        PointExtra<?> pointExtra;
        pointExtra = new PointExtra<Float>(4.3f,4.3f);
        pointExtra = new PointExtra<Integer>(3,3);
        pointExtra = new PointExtra<Float>(4.3f,4.3f);
        pointExtra = new PointExtra<Double>(4.3d,4.90d);
        pointExtra = new PointExtra<Long>();
//        pointExtra = new PointExtra<String>(); //编译错误
//        pointExtra = new PointExtra<Object>()  //编译错误


        /**
         * 2.4 通配符？的super绑定
         */
        List<? super Manager> list;
        list = new ArrayList<Employee>();
        //存
//        list.add(new Employee()); //编译错误
        list.add(new Manager());
        list.add(new CEO());
        //取
        Object object = list.get(0);
//        Employee employee = list.get(0);//编译错误

    }

    /**
     * 1.1 part
     */

    class Point<T> {
        private T x;       // 表示X坐标
        private T y;       // 表示Y坐标

        public Point(){

        }
        public Point(T x,T y){
            this.x = x;
            this.y = y;
        }

        public void setX(T x) {
            this.x = x;
        }

        public void setY(T y) {
            this.y = y;
        }

        public T getX() {
            return this.x;
        }

        public T getY() {
            return this.y;
        }
    }

    /**
     * 1.2part
     */
    public interface Comparable<T>{
        public boolean compareTo(T i);
    }

    //添加上extends Comparable之后，就可以Comparable里的函数了
    public static <T extends Comparable>  T min(T...a){
        T smallest = a[0];
        for(T item:a){
            if (smallest.compareTo(item)){
                smallest = item;
            }
        }
        return smallest;
    }

    public class StringCompare implements Comparable<StringCompare> {
        private String mStr;

        public StringCompare(String string){
            this.mStr = string;
        }

        @Override
        public  boolean compareTo(StringCompare str) {
            if (mStr.length() > str.mStr.length()){
                return true;
            }
            return false;
        }
    }



    /**
     * 1.3part
     */

    class Fruit {
        private String name;

        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }
    }

    public static <T extends Fruit> String getFruitName(T t){
        return t.getName();
    }

    class Banana extends Fruit{
        public Banana(){
            setName("bababa");
        }
    }
    class Apple extends Fruit{
        public Apple(){
            setName("apple");
        }
    }


    /**
     * 2.3 通配符？的extends绑定
     */
    class PointExtra<T extends Number> {
        private T x;       // 表示X坐标
        private T y;       // 表示Y坐标

        public PointExtra(){

        }
        public PointExtra(T x,T y){
            this.x = x;
            this.y = y;
        }

        public void setX(T x) {
            this.x = x;
        }

        public void setY(T y) {
            this.y = y;
        }

        public T getX() {
            return this.x;
        }

        public T getY() {
            return this.y;
        }
    }


    /**
     * 2.4 通配符？的super绑定
     */
    class CEO extends Manager {
    }

    class Manager extends Employee {
    }

    class Employee {
    }






}
