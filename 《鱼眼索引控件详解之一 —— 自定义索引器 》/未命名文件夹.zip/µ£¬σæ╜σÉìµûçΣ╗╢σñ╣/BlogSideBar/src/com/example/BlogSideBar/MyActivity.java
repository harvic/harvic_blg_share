package com.example.BlogSideBar;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;
import android.widget.TextView;

public class MyActivity extends Activity {

    private IndexSideBar mIndexSideBar; //首字母索引滑动view
    private TextView mIndexBlockDialog; //首字母索引放大指示器

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        mIndexSideBar = (IndexSideBar)findViewById(R.id.index_slide_bar);
        mIndexBlockDialog = (TextView)findViewById(R.id.index_slide_dialog);
        mIndexSideBar.setIndicatorTv(mIndexBlockDialog);
        mIndexSideBar.setChoosedListener(new IndexSideBar.ChooseListner() {
            @Override
            public void onChoosed(int pos,String text) {
                Log.e("qijian","pos:"+pos+"  choosed:"+ text);
            }
        });
    }
}
