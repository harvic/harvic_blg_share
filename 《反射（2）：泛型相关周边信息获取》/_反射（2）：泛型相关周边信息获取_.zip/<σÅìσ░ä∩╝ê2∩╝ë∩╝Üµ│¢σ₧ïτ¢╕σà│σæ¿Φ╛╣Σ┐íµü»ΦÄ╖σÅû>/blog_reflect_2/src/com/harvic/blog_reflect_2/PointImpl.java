package com.harvic.blog_reflect_2;

/**
 * Created by qijian on 15/11/20.
 */
public class PointImpl extends Point<Integer> implements PointInterface<String,Double> {

}
