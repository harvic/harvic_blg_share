package com.harvic.blog_reflect_2;

import java.util.ArrayList;

/**
 * Created by qijian on 15/11/23.
 * "ArrayList<T>是泛型"
 */
public class PointArrayImpl implements PointSingleInterface<Integer[]> {
}
