package com.harvic.blog_reflect_2;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.lang.reflect.*;
import java.util.Map;

public class MyActivity extends Activity {
    private String TAG = "qijian";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Button btn = (Button)findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    /**
                     * 1.1 获取泛型超类相信信息
                     */
                    getGenricitySuperClass();

                    /**
                     * 1.2 获取所继承泛型接口的相关信息
                     */
                    getGenericityInterface();

                    /**
                     * 2.1  TypeVariable
                     */
                    getGenericityInterface2();

                    /**
                     * 2.2 GenericArrayType
                     */
                    getGenericArrayTypeInterface();


                    /**
                     * 2.3 WildcardType
                     */
                    getWildcardTypeInterface();

                    /**
                     * 2.4 Demo：写一个通用类型转换函数
                     */
                    parseClass(PointWildcardImpl.class);
                }catch (Exception e){
                    Log.e(TAG,e.getMessage());
                }
            }
        });




    }

    /**
     * 获取泛型超类的填充信息
     * @throws Exception
     */
    private void getGenricitySuperClass() throws Exception {
        Class<?> clazz = PointImpl.class;
        Type type = clazz.getGenericSuperclass();
        if (type instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType) type;
            //返回表示此类型实际类型参数的 Type 对象的数组
            Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
            for (Type parameterArgType : actualTypeArguments) {
                Class parameterArgClass = (Class) parameterArgType;
                Log.d(TAG,"填充类型为：" + parameterArgClass.getName());
            }

            //返回 Type 对象，表示声明此类型的类或接口。
            Type type1 = parameterizedType.getRawType();
            Class class22 = (Class) type1;
            Log.d(TAG,"PointImpl的父类类型为："+class22.getName());

        }
    }


    /**
     * 获取泛型接口的填充信息
     * clazz.getGenericInterfaces()与clazz.getInterfaces()一样也只能获取直接继承接口的信息。
     * @throws Exception
     */
    private void getGenericityInterface() throws Exception{
        Class<?> clazz = PointImpl.class;
        Type[] types = clazz.getGenericInterfaces();
        for (Type type:types) {
            if (type instanceof ParameterizedType) {
                ParameterizedType parameterizedType = (ParameterizedType) type;
                //返回表示此类型实际类型参数的 Type 对象的数组
                Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
                for (Type parameterArgType : actualTypeArguments) {
                    Class parameterArgClass = (Class) parameterArgType;
                    Log.d(TAG, "此接口的填充类型为：" + parameterArgClass.getName());
                }

                //返回 Type 对象，表示声明此类型的类或接口。
                Type type1 = parameterizedType.getRawType();
                Class class22 = (Class) type1;
                Log.d(TAG,"声明此接口的类型为："+class22.getName());
            }
        }
    }


    private void getGenericityInterface2(){
        Class<?> clazz = PointGenericityImpl.class;
        Type[] types = clazz.getGenericInterfaces();
        for (Type type:types) {
            if (type instanceof ParameterizedType) {
                ParameterizedType parameterizedType = (ParameterizedType) type;
                //返回表示此类型实际类型参数的 Type 对象的数组
                Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
                for (Type parameterArgType : actualTypeArguments) {

                    if(parameterArgType instanceof TypeVariable){
                        TypeVariable typeVariable = (TypeVariable) parameterArgType;
                        Log.d(TAG, "此接口的填充类型为：" + typeVariable.getName());

                        //TODO 不是应该有上下边界么，为何只会打印出一个来
                        //返回表示此类型变量上边界的 Type 对象的数组。
                        Type[] typebounds = typeVariable.getBounds();
                        for (Type bound:typebounds){
                            Class<?> boundClass = (Class)bound;
                            //如果不写，则默认输出Object，如果写了，则输出对应的
                            Log.d(TAG, "bound为：" + boundClass.getName());
                        }
                    }

                    if (parameterArgType instanceof  Class){
                        Class parameterArgClass = (Class) parameterArgType;
                        Log.d(TAG, "此接口的填充类型为：" + parameterArgClass.getName());
                    }
                }

            }
        }
    }



    private void getWildcardTypeInterface(){
        Class<?> clazz = PointWildcardImpl.class;
        //此时的type对应PointSingleInterface<Comparable<? extends Number>>
        Type[] types = clazz.getGenericInterfaces();
        for (Type type:types) {
            if (type instanceof ParameterizedType) {
                ParameterizedType parameterizedType = (ParameterizedType) type;
                //得到填充PointSingleInterface的具体参数，即：Comparable<? extends Number>，仍然是一个ParameterizedType
                Type[] actualTypes = parameterizedType.getActualTypeArguments();
                for (Type actualType : actualTypes) {
                    if (actualType instanceof ParameterizedType) {
                        ParameterizedType ComparableType = (ParameterizedType) actualType;
                        //对Comparable<? extends Number>再取填充参数，得到的type对应<? extends Number>，这个就是WildcardType了
                        Type[] compareArgs = ComparableType.getActualTypeArguments();
                        for (Type Arg:compareArgs){
                            if(Arg instanceof WildcardType){
                                //将得到的对应WildcardType的type强转为WildcardType的变量
                                WildcardType wt = (WildcardType) Arg;

                                //利用getLowerBounds得到下界，即派生自Super的限定，如果没有派生自super则为null
                                Type[] lowerBounds = wt.getLowerBounds();
                                for (Type bound:lowerBounds){
                                    Class<?> boundClass = (Class)bound;
                                    Log.d(TAG, "lowerBound为：" + boundClass.getName());
                                }

                                //通过getUpperBounds得到上界，即派生自extends的限定，如果没有，默认是Object
                                Type[] upperBounds = wt.getUpperBounds();
                                for (Type bound:upperBounds){
                                    Class<?> boundClass = (Class)bound;
                                    //如果不写，则默认输出Object，如果写了，则输出对应的
                                    Log.d(TAG, "upperBound为：" + boundClass.getName());
                                }

                            }
                        }
                    }
                }

            }
        }
    }

    //注意，"ArrayList<T>是泛型"
    //只有类似String[]这种的类型才是GenericArrayType
    private void getGenericArrayTypeInterface(){
        Class<?> clazz = PointArrayImpl.class;
        Type[] interfaces = clazz.getGenericInterfaces();
        for (Type type:interfaces){
            if (type instanceof ParameterizedType) {
                ParameterizedType pt = (ParameterizedType) type;
                Type[] actualArgs = pt.getActualTypeArguments();
                for (Type arg:actualArgs){
                    if (arg instanceof GenericArrayType){
                        GenericArrayType arrayType = (GenericArrayType)arg;
                        Type comType = arrayType.getGenericComponentType();
                        Class<?> typeClass = (Class)comType;
                        Log.d(TAG,"数组类型为："+typeClass.getName());
                    }

                }
            }
        }

    }



    private void parseClass(Class<?> c){
        parseTypeParameters(c.getGenericInterfaces());
    }

    private void parseTypeParameters(Type[] types){
        for(Type type:types){
            parseTypeParameter(type);
        }
    }

    private void parseTypeParameter(Type type){
        if(type instanceof Class){
            Class<?> c = (Class<?>) type;
            Log.d(TAG, c.getSimpleName());
        } else if(type instanceof TypeVariable){
            TypeVariable<?> tv = (TypeVariable<?>)type;
            Log.d(TAG, tv.getName());
            parseTypeParameters(tv.getBounds());
        } else if(type instanceof WildcardType){
            WildcardType wt = (WildcardType)type;
            Log.d(TAG, "?");
            parseTypeParameters(wt.getUpperBounds());
            parseTypeParameters(wt.getLowerBounds());
        } else if(type instanceof ParameterizedType){
            ParameterizedType pt = (ParameterizedType)type;
            Type t = pt.getOwnerType();
            if(t != null) {
                parseTypeParameter(t);
            }
            parseTypeParameter(pt.getRawType());
            parseTypeParameters(pt.getActualTypeArguments());
        } else if (type instanceof GenericArrayType){
            GenericArrayType arrayType = (GenericArrayType)type;
            Type t = arrayType.getGenericComponentType();
            parseTypeParameter(t);
        }
    }









}
