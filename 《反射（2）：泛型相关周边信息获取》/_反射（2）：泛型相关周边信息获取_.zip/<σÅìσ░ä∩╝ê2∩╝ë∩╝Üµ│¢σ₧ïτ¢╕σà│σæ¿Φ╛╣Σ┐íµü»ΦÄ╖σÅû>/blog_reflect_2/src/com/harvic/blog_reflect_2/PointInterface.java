package com.harvic.blog_reflect_2;

/**
 * Created by qijian on 15/11/22.
 */
public interface PointInterface<T,U> {
}
