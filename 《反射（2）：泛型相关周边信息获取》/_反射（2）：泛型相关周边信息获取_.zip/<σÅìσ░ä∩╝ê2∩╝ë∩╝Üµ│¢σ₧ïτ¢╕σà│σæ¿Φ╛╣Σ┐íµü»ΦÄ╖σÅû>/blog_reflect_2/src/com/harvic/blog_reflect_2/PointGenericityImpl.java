package com.harvic.blog_reflect_2;

import java.io.Serializable;
import java.util.AbstractList;
import java.util.ArrayList;

/**
 * Created by qijian on 15/11/23.
 */
public class PointGenericityImpl<T extends Number&Serializable> implements PointInterface<T,Integer> {
}
