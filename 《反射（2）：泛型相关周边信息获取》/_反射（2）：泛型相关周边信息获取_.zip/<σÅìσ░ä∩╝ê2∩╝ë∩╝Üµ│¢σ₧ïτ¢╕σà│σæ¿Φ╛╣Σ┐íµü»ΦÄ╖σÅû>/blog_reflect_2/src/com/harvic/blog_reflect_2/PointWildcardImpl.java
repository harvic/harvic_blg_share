package com.harvic.blog_reflect_2;


/**
 * Created by qijian on 15/11/23.
 */
public class PointWildcardImpl implements PointSingleInterface<Comparable<? extends Number>> {
}


