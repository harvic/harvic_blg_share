package com.harvic.BlogRadialGradient;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by qijian on 16/9/24.
 */
public class MultiColorActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.multi_color_activity);
    }
}
