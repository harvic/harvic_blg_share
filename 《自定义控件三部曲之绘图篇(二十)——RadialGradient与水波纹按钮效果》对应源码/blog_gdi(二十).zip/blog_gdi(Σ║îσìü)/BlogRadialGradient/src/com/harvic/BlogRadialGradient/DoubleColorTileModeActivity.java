package com.harvic.BlogRadialGradient;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by qijian on 16/9/24.
 */
public class DoubleColorTileModeActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.double_color_tile_mode);
    }
}
