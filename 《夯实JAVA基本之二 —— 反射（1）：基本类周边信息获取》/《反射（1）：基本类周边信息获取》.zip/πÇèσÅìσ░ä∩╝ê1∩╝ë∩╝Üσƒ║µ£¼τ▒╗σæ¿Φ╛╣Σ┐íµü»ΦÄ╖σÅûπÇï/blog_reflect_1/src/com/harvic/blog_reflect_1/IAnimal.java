package com.harvic.blog_reflect_1;

/**
 * Created by qijian on 15/11/20.
 */
public interface IAnimal {
    void setName(String name);
    String getName();
}
