package com.harvic.blog_reflect_1;

import android.app.Activity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.lang.reflect.Modifier;

public class MyActivity extends Activity {
    private String TAG = "qijian";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Button btn = (Button) findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    /**
                     * 获取类类型的方法
                     */
                    createClassDemo();

                    /**
                     * 2.1类名，包名获取
                     */
                    getPackageAndName();

                    /**
                     * 2.2 获取超类superclass的Class对象
                     */
                    getSuperClass();

                    /**
                     * 2.3 获取类所直接继承的接口的Class对象
                     */
                    getInterfaceClas();

                    /**
                     * 2.4 递规获取所有接口
                     */
                    Class<?>[] clazzes = getAllInterface(AnimalImpl.class);
                    SpannableStringBuilder builder = new SpannableStringBuilder();
                    for (Class clazz : clazzes) {
                        builder.append(clazz.getName());
                        builder.append("   ");
                    }
                    Log.d(TAG, "AnimalImpl继承的所有接口:" + builder.toString());

                    /**
                     * 2.5 获取类的访问修饰符
                     */
                    getclassModifiers();

                    /**
                     * 获取接口的访问修饰符
                     */
                    getInterfaceModifiers();


                } catch (Exception e) {
                    Log.e(TAG, e.getMessage());
                }
            }
        });
    }

    /**
     * 获取类类型的方法
     *
     * @throws Exception
     */
    public void createClassDemo() throws Exception {
        //方法一
        Animal animal = new Animal();
        Class<?> clazz1 = animal.getClass();
        //方法二
        Class<?> clazz2 = Animal.class;
        //方法三
        Class<?> clazz3 = Class.forName("com.harvic.blog_reflect_1.Animal");
        //方法四
        Class<?> clazz4 = getClassLoader().loadClass("com.harvic.blog_reflect_1.Animal");

        //类只会被加载一次，所以clazz1，clazz2，clazz3，clazz4都是相等的
        boolean result = (clazz1 == clazz2 && clazz3 == clazz4 && clazz1 == clazz3);
        Log.d(TAG, "这四个class的对象对比的结果是：" + result + "");

    }

    /**
     * 2.1类名，包名获取
     */
    public void getPackageAndName() {
        Class<?> clazz = Animal.class;
        Package package1 = clazz.getPackage();
        Log.d(TAG, "完整的类名：" + clazz.getName());
        Log.d(TAG, "仅获取类名：" + clazz.getSimpleName());
        Log.d(TAG, "包名：" + package1.getName());
    }

    /**
     * 获取超类superclass的Class对象
     *
     * @throws Exception
     */
    public void getSuperClass() throws Exception {
        //获取超类Class对象
        Class<?> clazz = Class.forName("com.harvic.blog_reflect_1.AnimalImpl");
        Class<?> parentClass = clazz.getSuperclass();
        Log.d(TAG, "父类：" + parentClass.getName());
    }

    /**
     * 获取类所直接继承的接口的Class对象
     *
     * @throws Exception
     */
    public void getInterfaceClas() throws Exception {
        Class<?> class3 = Animal.class;
        Class<?>[] interfaces = class3.getInterfaces();
        for (Class interItem : interfaces) {
            Log.d(TAG, "Animal继承的接口：" + interItem.getName());
        }

        class3 = AnimalImpl.class;
        interfaces = class3.getInterfaces();
        if (interfaces.length > 0) {
            for (Class interItem : interfaces) {
                Log.d(TAG, "AnimalImpl继承的接口：" + interItem.getName());
            }
        } else {
            Log.d(TAG, "AnimalImpl无继承的接口");
        }
    }

    /**
     * 获取所传类类型的所有继承的接口列表
     *
     * @param clazz
     * @return
     */
    public Class<?>[] getAllInterface(Class<?> clazz) {

        //获取自身的所有接口
        Class<?>[] interSelf = clazz.getInterfaces();
        //递规调用getAllInterface获取超类的所有接口
        Class<?> superClazz = clazz.getSuperclass();
        Class<?>[] interParent = null;
        if (null != superClazz) {
            interParent = getAllInterface(superClazz);
        }

        //返回值
        if (interParent == null && interSelf != null) {
            return interSelf;
        } else if (interParent == null && interSelf == null) {
            return null;
        } else if (interParent != null && interSelf == null) {
            return interParent;
        } else {
            final int length = interParent.length + interSelf.length;
            Class<?>[] result = new Class[length];
            System.arraycopy(interSelf, 0, result, 0, interSelf.length);
            System.arraycopy(interParent, 0, result, interSelf.length, interParent.length);
            return result;
        }
    }

    /**
     * 获取类的访问修饰符
     *
     * @throws Exception
     */
    public void getclassModifiers() throws Exception {
        //返回类的定义修饰符
        Class<?> clazz = getClassLoader().loadClass(InnerClass.class.getName());
        int modifiers = clazz.getModifiers();
        String retval = Modifier.toString(modifiers);
        boolean isFinal = Modifier.isFinal(modifiers);
        Log.d(TAG, "InnerClass的定义修饰符:" + retval);
        Log.d(TAG, "is Final:" + isFinal);
    }

    /**
     * 获取接口的访问修饰符
     *
     * @throws Exception
     */
    public void getInterfaceModifiers() throws Exception {
        //获取接口的访问修饰符
        Class<?> clazz2 = InnerInteface.class;
        int modifiers = clazz2.getModifiers();
        String retval = Modifier.toString(modifiers);
        boolean isInteface = Modifier.isInterface(modifiers);
        Log.d(TAG, "InnerClass的定义修饰符:" + retval);
        Log.d(TAG, "isInteface:" + isInteface);

    }


    public static final class InnerClass {

    }

    public static interface InnerInteface {

    }


}
