package com.harvic.blog_reflect_1;

import java.io.Serializable;

/**
 * Created by qijian on 15/11/20.
 */
public class Animal implements IAnimal,Serializable{
    private String name;

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }
}