package com.harvic.blog_reflect_1;

import java.io.Serializable;

/**
 * Created by qijian on 15/11/20.
 */
public final class AnimalImpl extends Animal implements Serializable {
}
