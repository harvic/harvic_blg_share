package com.harvic.blog_reflect_3;

import android.support.v4.app.Fragment;
import android.util.Log;

/**
 * Created by qijian on 15/11/27.
 */
public class DemoFragment extends Fragment {
    public void printFragment(String name){
        Log.d("qijian",name+"就知道你是个逗逼");
    }
}
