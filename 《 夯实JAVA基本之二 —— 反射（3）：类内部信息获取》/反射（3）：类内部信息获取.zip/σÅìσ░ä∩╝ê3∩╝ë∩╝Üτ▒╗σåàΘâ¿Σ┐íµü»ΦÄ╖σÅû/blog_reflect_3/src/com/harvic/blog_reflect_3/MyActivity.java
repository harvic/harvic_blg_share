package com.harvic.blog_reflect_3;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import android.support.v4.app.Fragment;
import android.widget.PopupWindow;

public class MyActivity extends Activity {
    private String TAG = "qijian";

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Button btn = (Button) findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    getConstructorList();

                    newInstanceDemo();

                    getConstructorParamsType();

                    getModifiersDemo();

                    getDeclareClassDemo();

                    getFieldsDemo();

                    fieldgetset();

                    getMethodDemo();

                    methodInvokeDemo();

                    getMethodParams();

                    getMethodReturnType();

                    FragmentInstantiate();
                } catch (Exception e) {
                    Log.e(TAG, e.getMessage());
                }
            }
        });
    }

    public void getConstructorList() throws Exception {
        //1、枚举
        Class<?> clazz = Person.class;
        Constructor<?>[] constructors = clazz.getDeclaredConstructors();
        for (Constructor item : constructors) {
            Log.d(TAG, "枚举到的构造函数：" + item.toString());
        }

        //2、根据类型，获取指定的构造的构造函数
        Constructor<?> constructor = clazz.getDeclaredConstructor(Integer.class, String.class);
        Log.d(TAG, "指定参数得到的构造函数：" + constructor.toString());

    }

    public void newInstanceDemo() throws Exception {
        Class<?> clazz = Person.class;
        Constructor<?> constructor = clazz.getDeclaredConstructor(Integer.class, String.class);
        constructor.setAccessible(true);

        //构造实例一
        Person person1 = (Person) constructor.newInstance(new Integer(30), new String("harvic"));
        Log.d(TAG, "构造的参数为：" + person1.getName() + "  " + person1.getAge());

        //构造实例二
        Person person2 = (Person) constructor.newInstance(50, "qijian");
        Log.d(TAG, "构造的参数为：" + person2.getName() + "  " + person2.getAge());

        try {
            //构造实例三
            Person person3 = (Person) constructor.newInstance();
            person3.setAge(30);
            person3.setName("qijian");
            Log.d(TAG, "构造的参数为：" + person3.getName() + "  " + person3.getAge());
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }

    public void getConstructorParamsType() throws Exception {
        Class<?> clazz = Person.class;
        Constructor<?>[] constructors = clazz.getDeclaredConstructors();
        for (Constructor<?> c : constructors) {
            c.setAccessible(true);
            Class<?>[] types = c.getParameterTypes();

            StringBuilder builder = new StringBuilder("获取参数类型为：");
            for (Class t : types) {
                builder.append(t.getName());
                builder.append("   ");
            }
            Log.d(TAG, builder.toString());
        }
    }

    public void getModifiersDemo() throws Exception {
        Class<?> clazz = Person.class;
        Constructor<?>[] constructors = clazz.getDeclaredConstructors();
        for (Constructor<?> c : constructors) {
            c.setAccessible(true);

            int modifier = c.getModifiers();
            Log.d(TAG, "一个访问修饰符为：" + Modifier.toString(modifier));
        }
    }

    public void getDeclareClassDemo() throws Exception {
        Class<?> clazz = Person.class;
        Constructor<?> constructor = clazz.getDeclaredConstructor();
        Class<?> declarClazz = constructor.getDeclaringClass();
        Log.d(TAG, declarClazz.getName());
    }

    public void getFieldsDemo() throws Exception {
        Class<?> clazz = Person.class;
        //1、枚举
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);
            Class<?> type = field.getType();
            Log.d(TAG, "枚举到的field:" + type.getName() + "  " + field.getName());
        }
        //2、指定名称
        Field field = clazz.getDeclaredField("age");
        field.setAccessible(true);
        Class<?> type = field.getType();
        Log.d(TAG, "得到age对应的field:" + type.getName() + "  " + field.getName());


    }

    public void fieldgetset() throws Exception{
        Class<?> clazz = Person.class;
        Constructor<?> constructor = clazz.getConstructor();
        Person person = (Person)constructor.newInstance();

        //示例1：get() set()函数
        Field fName = clazz.getDeclaredField("name");
        fName.setAccessible(true);
        fName.set(person, "qijian");
        String val = (String)fName.get(person);
        //利用set设置
        Log.d(TAG, "fieldName:" + val + "   personName:" + person.getName());

        //示例2：getInt()与setInt()
        Field fAge = clazz.getDeclaredField("age");
        fAge.setAccessible(true);
        fAge.setInt(person, 20);
        Log.d(TAG, "fieldAge:" + fAge.getInt(person) + "   personAge:" + person.getAge());

        //示例3：给声明为原始类型的变量使用get()、set()
        Field fAge2 = clazz.getDeclaredField("age");
        fAge2.setAccessible(true);
        fAge2.set(person, 30);
        Integer ageval = (Integer)fAge2.get(person);
        Log.d(TAG, "fieldAge:" + ageval.toString() + "   personAge:" + person.getAge());

        //示例4：isEnumConstant()
        Class<?> clazz2 = Person.COLOR.class;
        Field field = clazz2.getDeclaredField("WHITE");
        Log.d(TAG,"COLOR.WHITE是否是枚举常量："+field.isEnumConstant()+"");

        Field fColor = clazz.getDeclaredField("color");
        fColor.setAccessible(true);
        boolean isEnum = fColor.isEnumConstant();
        Log.d(TAG,"color是否是枚举常量："+isEnum);
    }

    public void getMethodDemo() throws Exception{
        Class<?> clazz = Person.class;
        Method[] methods = clazz.getDeclaredMethods();
        for (Method m:methods){
            Log.d(TAG,"枚举到的方法："+m.toString());
        }

        Method method = clazz.getDeclaredMethod("setName",String.class);
        Log.d(TAG,"得到指定方法1："+method.toString());

        Method method1 = clazz.getDeclaredMethod("setAge",int.class);
        Log.d(TAG,"得到指定方法2："+method1.toString());
    }

    public void methodInvokeDemo() throws Exception{
        Class<?> clazz = Person.class;
        Person person = new Person();
        Method method = clazz.getDeclaredMethod("testInvoke", Integer.class,String.class);

        method.setAccessible(true);
        Boolean result = (Boolean)method.invoke(person, 25, "I m harvic");
        Log.d(TAG,"执行结果:"+result);
    }

    public void getMethodParams()throws Exception{
        Class<?> clazz  = Person.class;
        Method method = clazz.getDeclaredMethod("testInvoke", Integer.class,String.class);

        Class<?>[] params = method.getParameterTypes();
        for (Class c:params){
            Log.d(TAG,"枚举到参数类型："+c.getName());
        }
    }

    public void getMethodReturnType() throws Exception{
        Class<?> clazz  = Person.class;
        Method method = clazz.getDeclaredMethod("testInvoke", Integer.class,String.class);

        Class type = method.getReturnType();
        Log.d(TAG,"返回值类型为："+type.getName());
    }

    public void FragmentInstantiate(){
        Class<?> clazz = DemoFragment.class;
        DemoFragment fragment = (DemoFragment) Fragment.instantiate(this,clazz.getName(),null);
        fragment.printFragment("harvic");
    }



}
