package com.harvic.blog_reflect_3;

import android.util.Log;

import java.util.ArrayList;

/**
 * Created by qijian on 15/11/17.
 */
public class Person {
    public static enum COLOR{WHITE,BLACK,YELLOW}
    private int age;
    private String name;
    private COLOR color;
    public Person(){
    }
    private Person(int age, String name){
        this.age = age;
        this.name = name;
    }

    private Person(Integer age, String name){
        this.age = age;
        this.name = name;
    }

    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public Boolean testInvoke(Integer age,String name){
        Log.d("qijian","得到参数age:"+age +"   name:"+name);
        return true;
    }

}
