package com.example.BlogSideBar;

import android.util.SparseIntArray;
import android.widget.SectionIndexer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qijian on 16/1/3.
 */
public class CustomIndexer implements SectionIndexer {
    private String[] mIndexStrings;
    private List<String> mDatas = new ArrayList<>();
    /**
     * This contains a cache of the computed indices so far. It will get reset whenever
     * the dataset changes or the cursor changes.
     */
    private SparseIntArray mAlphaMap;

    public CustomIndexer(List<String> datas, String[] indexStrs){
        mDatas.addAll(datas);
        mIndexStrings = indexStrs;
        mAlphaMap = new SparseIntArray(mIndexStrings.length);
    }

    /**
     * 返回索引字符数组
     * @return
     */
    @Override
    public String[] getSections() {
        return mIndexStrings;
    }


    /**
     * 根据item的位置返回当前索引的位置
     * @param position
     * @return
     */
    @Override
    public int getSectionForPosition(int position) {
        return 0;
    }


    /**
     * 根据索引返回当前首项位置
     * @param section
     * @return
     */
    @Override
    public int getPositionForSection(int section) {
        final SparseIntArray alphaMap = mAlphaMap;
        final List<String> items = mDatas;

        if (items == null || mIndexStrings == null) {
            return 0;
        }

        if (section <= 0) {
            return 0;
        }
        if (section >= mIndexStrings.length) {
            section = mIndexStrings.length - 1;
        }

        int count = items.size();
        int start = 0;
        int end = count;
        int pos;

        char letter = mIndexStrings[section].charAt(0);
        String targetLetter = Character.toString(letter);
        int key = letter;
        // 检查map是否已经保存了key为letter的对应索引,如果有的话直接返回,如果没有则进行查找
        if (Integer.MIN_VALUE != (pos = alphaMap.get(key, Integer.MIN_VALUE))) {
            // Is it approximate? Using negative value to indicate that it's
            // an approximation and positive value when it is the accurate
            // position.
            if (pos < 0) {
                //如果没有,则将end设为一个极大值,以保证利用二分查找时,肯定能包含listview中所有item的索引
                pos = -pos;
                end = pos;
            } else {
                // Not approximate, this is the confirmed start of section, return it
                return pos;
            }
        }

        //利用前一个字母的位置缩短查找距离
        //由于索引条中的字母都是按顺序排列的,所以要找索引为section的字母对应item在listview中的位置,先看看它的前一个字母
        //是不是在alphaMap是不是已经有保存对应item的位置了,如果有的话,我们又可以缩短查找距离,直接用前一个字母的位置做为开始即可
        if (section > 0) {
            int prevLetter = mIndexStrings[section-1].charAt(0);
            int prevLetterPos = alphaMap.get(prevLetter, Integer.MIN_VALUE);
            if (prevLetterPos != Integer.MIN_VALUE) {
                start = Math.abs(prevLetterPos);
            }
        }

        // Now that we have a possibly optimized start and end, let's binary search

        pos = (end + start) / 2;

        while (pos < end) {
            // Get letter at pos
            String item = items.get(pos);
            String curName = "";
            if (item != null) {
                curName = item.charAt(0)+"";
            }
            if (curName == null) {
                if (pos == 0) {
                    break;
                } else {
                    pos--;
                    continue;
                }
            }
            int diff = compare(curName, targetLetter);
            if (diff != 0) {
                if (diff < 0) {
                    //如果已经到了Listview的末尾,但仍没有索引字符对应的item,就将最末Item的索引返回.
                    start = pos + 1;
                    if (start >= count) {
                        pos = count;
                        break;
                    }
                } else {
                    end = pos;
                }
            } else {
                // They're the same, but that doesn't mean it's the start
                if (start == pos) {
                    // This is it
                    break;
                } else {
                    // Need to go further lower to find the starting row
                    end = pos;
                }
            }
            pos = (start + end) / 2;
        }
        alphaMap.put(key, pos);
        return pos;
    }

    /**
     * 首字母比较规则
     * @param firstLetter 第一个字母
     * @param secondLetter 第二个字母
     * @return 比较返回值
     */
    protected int compare(String firstLetter, String secondLetter) {
        if (firstLetter == null||firstLetter.length() == 0) {
            firstLetter = " ";
        } else {
            firstLetter = firstLetter.substring(0, 1);
        }
        if (secondLetter == null||secondLetter.length() == 0) {
            secondLetter = " ";
        } else {
            secondLetter = secondLetter.substring(0, 1);
        }

        return firstLetter.compareTo(secondLetter);
    }
}
