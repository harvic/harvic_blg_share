package com.example.BlogSideBar;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MyActivity extends Activity {

    private IndexSideBar mIndexSideBar; //首字母索引滑动view
    private TextView mIndexBlockDialog; //首字母索引放大指示器

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        //构造listview
        final ListView listView = (ListView)findViewById(R.id.list);
        List<String> datas = getData();
        listView.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1,datas));

        final CustomIndexer indexer = new CustomIndexer(datas,IndexSideBar.b);

        mIndexSideBar = (IndexSideBar)findViewById(R.id.index_slide_bar);
        mIndexBlockDialog = (TextView)findViewById(R.id.index_slide_dialog);
        mIndexSideBar.setIndicatorTv(mIndexBlockDialog);
        mIndexSideBar.setChoosedListener(new IndexSideBar.ChooseListner() {
            @Override
            public void onChoosed(int pos,String text) {
                Log.e("qijian","pos:"+pos+"  choosed:"+ text);
                int itemPos = indexer.getPositionForSection(pos);
                listView.setSelection(itemPos);
            }
        });
    }

    private List<String> getData(){
        String[] indexeStrs = IndexSideBar.b;

        List<String> data = new ArrayList<String>();
        for (String str:indexeStrs){
            for (int i = 1;i<=10;i++){
                data.add(str + i);
            }
        }
        return data;
    }
}
