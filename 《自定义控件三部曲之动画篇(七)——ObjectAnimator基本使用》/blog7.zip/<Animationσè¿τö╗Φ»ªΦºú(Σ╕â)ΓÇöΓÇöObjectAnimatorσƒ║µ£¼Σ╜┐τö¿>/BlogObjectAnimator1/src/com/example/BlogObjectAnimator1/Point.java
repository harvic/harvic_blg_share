package com.example.BlogObjectAnimator1;

/**
 * Created by qijian on 16/1/17.
 */
public class Point {
    private int mRadius;

    public Point(int radius){
        mRadius = radius;
    }

    public int getRadius() {
        return mRadius;
    }

    public void setRadius(int radius) {
        mRadius = radius;
    }
}
